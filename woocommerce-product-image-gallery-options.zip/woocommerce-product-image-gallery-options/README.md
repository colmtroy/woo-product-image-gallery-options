WooCommerce Product Image Gallery Options
===================

Switch on/off WooCommerce 3.0+ Product Image Gallery options on a per product basis.

### Features

* Hide the Image Zoom feature on a per product basis.
* Hide the Image Lightbox feature on a per product basis.
* Hide the Image Slider feature on a per product basis.